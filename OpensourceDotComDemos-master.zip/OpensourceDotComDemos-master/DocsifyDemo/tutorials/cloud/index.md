# Tutorial for Cloud

Are you new to cloud? Cloud platform became hugely popular in the recent years. There are three types of cloud platforms:

- Infrastructre as a Service (IaaS)
- Platform as a Service (PaaS)
- Software as a Service (SaaS)

But recently, we also have other services getting invented such as **Container as a Service (CaaS)**.

